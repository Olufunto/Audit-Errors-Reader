
SET feedback OFF;
conn pto/pto@xe

@C:\Repo\pto_audit\src\sql\cleanup.sql

@C:\Repo\pto_audit\src\sql\ak_script.sql
@C:\Repo\pto_audit\src\sql\OFC_script.sql
@C:\Repo\pto_audit\src\sql\CLC_script.sql

exit